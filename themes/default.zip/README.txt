Teralth Wiki — Default page source

This editable Default theme template contains its settings and stylesheet at the
archive root, plus copies of the public page shell and stylesheet under source/.
It intentionally excludes
server code, secrets, dependencies, and executable JavaScript.

Files:
- settings.json: theme identity and settings displayed in the Themes panel.
- theme.css: scoped stylesheet used by the theme.
- source/public/index.html: public page shell reference for theme authors.
- source/public/styles.css: full public stylesheet reference for theme authors.

Edit settings.json and theme.css, give the theme a name other than Default, and
upload this ZIP in the Themes panel. The source/public files are retained as editable reference files;
the application continues to render its own public shell and does not execute
or serve uploaded HTML. Do not add scripts, secrets, or external asset URLs.
