Teralth Wiki — Default page source

This editable source bundle contains the public page shell and its stylesheet,
plus the Default theme settings and stylesheet. It intentionally excludes
server code, secrets, dependencies, and executable JavaScript.

Files:
- public/index.html: page structure and interface landmarks.
- public/styles.css: page and responsive styles.
- theme/settings.json: settings displayed in the Themes panel.
- theme/theme.css: scoped Default theme stylesheet.

Keep the IDs and data attributes used by the application when editing the HTML.
The panel's installable theme ZIP format remains settings.json + theme.css at
the archive root; this bundle is the editable full-page source reference.
